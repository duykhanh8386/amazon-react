import { useDispatch } from "react-redux";
import { useRef } from "react";
import { deleteItem, updateQuantity } from "../../component/action/cart";

function CartItem(props){
  const {item}=props;
    const dispatch = useDispatch();
    const inputRef=useRef();
    const handleUp=()=>{
        dispatch(updateQuantity(item.id));
        inputRef.current.value = parseInt(inputRef.current.value) +1;
    }
    const handleDown=()=>{
        if(item.quantity>1){
            dispatch(updateQuantity(item.id, -1));
        inputRef.current.value = parseInt(inputRef.current.value) -1;
        }
        
    }
    const handleDelete=()=>{
        dispatch(deleteItem(item.id, -1));
    }
    return(
        <>
        <div className="cart__item" >
                    <div className="cart__image">
                        <img src={item.info.image} alt={item.info.name}/>
                    </div>
                    <div className="cart__content">
                        <h4 className="cart__title">{item.info.name}</h4>
                        <div className="cart__price--new">{(item.info.price*(100-item.info.discount)/100).toFixed(0)}$</div>
                        <div className="cart__price--old">{item.info.price}$</div>
                    </div>
                    <div className="cart__quantity">
                    <button onClick={handleDown}>-</button>
                    <input ref={inputRef} defaultValue={item.quantity}/>
                    <button onClick={handleUp}>+</button>
                    </div>
                    <button onClick={handleDelete}>Xoa</button>
                    </div>
        </>
    )
}
export default CartItem;