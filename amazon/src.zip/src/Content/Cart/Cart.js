import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import { deleteAll } from "../../component/action/cart";
import CartList from "./CartList";

function Cart(){
  const cart = useSelector(state=>state.cartReducer);
  const dispatch = useDispatch();
  const locations = useLocation();
  const {totalItem} = locations.state;
  const total = cart.reduce((sum,item)=>{
    const priceNew = item.info.price*(100-item.info.discount)/100;
    return sum+ priceNew*item.quantity;
  },0);
  const handleDeleteAll=()=>{
    dispatch(deleteAll());
  }
    return(
        <>
        <div className="cart__title">
          Shopping Cart
        </div>
        <button onClick={handleDeleteAll}>Delete All</button>
        <div>
          {cart.length >0 ?(
            <>
              <CartList/>
              <div className="sub__total">
                Subtoal {totalItem+(" item")}: <div>${total.toFixed(0)}</div>

              </div>
            </>
          ):(
            <>No item added</>
          )

          }
        </div>
        </>
    )
}
export default Cart;