import logo from './logo.svg';
import './App.css';
import Layout from './Layout';
import AllRoutes from './component/AllRoutes';

function App() {
  return (
    <>
     <AllRoutes/>
    </>
  );
}

export default App;
