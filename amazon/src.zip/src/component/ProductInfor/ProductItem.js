import { Col, Row, Image } from "antd";
import { useLocation } from "react-router-dom";
import "./ProductItem.scss";
import { StarFilled } from "@ant-design/icons"
function ProductItem() {
  const locations = useLocation();
  const { item } = locations.state;
  return (
    <>
      <Row gutter={[20, 20]} className="mt-20">
        <Col xxl={10} xl={10} lg={10} md={24} sm={24} xs={24}>
          <Image className="productDetail__image" src={item.image} alt={item.name} />
        </Col>
        <Col xxl={10} xl={10} lg={10} md={24} sm={24} xs={24}>
          <div className="productDetail__info">
            <div className="productDetail__info--title">
              {item.name}
            </div>

            <div className="productDetail__sold">
              <div className="productDetail__sold--star">
                <StarFilled style={{ color: "#DE7921" }} />
                <StarFilled style={{ color: "#DE7921" }} />
                <StarFilled style={{ color: "#DE7921" }} />
                <StarFilled style={{ color: "#DE7921" }} />
                <StarFilled style={{ color: "#DE7921" }} />
              </div>
              <div className="productDetail__sold--count">{item.sold} bought in past month</div>
            </div>
            <div className="product__recomment">Amazon's choice</div>
            <hr></hr>
            <div className="productDetail__discount--title">Limited time deal</div>
            <div className="productDetail__discount">
              <div className="productDetail__discount--price">- {item.discount}% to </div>
              <div className="productDetail__price--new">
                ${(item.price * (100 - Number(item.discount)) / 100).toFixed(0)}
              </div>
            </div>
            <div className="productDetail__price">
              Typical <span className="productDetail__price--old">${item.price}</span>
            </div>
            <div className="productDetail__shipping">
              <span className="productDetail__shipping--cost">
                No Import Charges & $27.82 Shipping to Vietnam Details
              </span>
              <span className="productDetail__shipping--rule">30-day refund/replacement</span>
            </div>
            <div className="productDetail__specs">
              <div className="productDetail__specs--item"><strong>Color</strong><span>Multicolor</span></div>
              <div className="productDetail__specs--item"><strong>Brand</strong><span>REEMEER</span></div>
              <div className="productDetail__specs--item"><strong>Indoor/Outdoor Usage</strong><span>Indoor</span></div>
              <div className="productDetail__specs--item"><strong>Special Feature</strong><span>Corded</span></div>
              <div className="productDetail__specs--item"><strong>Light Source Type</strong><span>LED</span></div>
              <div className="productDetail__specs--item"><strong>Power Source</strong><span>AC</span></div>
              <div className="productDetail__specs--item"><strong>Light Color</strong><span>Multicolor</span></div>
              <div className="productDetail__specs--item"><strong>Theme</strong><span>Christmas, weddings, Halloween, parties</span></div>
              <div className="productDetail__specs--item"><strong>Occasion</strong><span>Christmas, weddings, Halloween, parties</span></div>
              <div className="productDetail__specs--item"><strong>Style</strong><span>Hiện đại</span></div>
            </div>

            <div className="productDetail__desc">
              <h2>About this system</h2>
              <div className="productDetail__desc--info">
                <pre>{item.description}</pre>
              </div>
            </div>
          </div>
        </Col>
        <Col xxl={4} xl={4} lg={4} md={24} sm={24} xs={24}></Col>
      </Row>

    </>
  )
}
export default ProductItem;