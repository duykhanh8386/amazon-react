import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import {ShoppingCartOutlined} from "@ant-design/icons"
function CartMini(){
  const cart = useSelector(state => state.cartReducer);

  const totalItem = cart.reduce((sum,item)=>{
    return sum+ item.quantity;
  },0);

  return(
    <>
    <Link className="cart" to="/cart" state={{totalItem}}><ShoppingCartOutlined style={{ fontSize: "40px" }} />
    <span>({totalItem})</span></Link>
    
    </>
  )
}
export default CartMini;